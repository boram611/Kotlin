package com.kotlinlec.hybrid01

import android.net.http.SslError
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button

class MainActivity : AppCompatActivity() {

    var webview: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn_page1: Button = findViewById(R.id.btn_page1)
        val btn_page2: Button = findViewById(R.id.btn_page2)
        val btn_page3: Button = findViewById(R.id.btn_page3)

        webview = findViewById(R.id.webview)

        btn_page1.setOnClickListener(onClickListener)
        btn_page2.setOnClickListener(onClickListener)
        btn_page3.setOnClickListener(onClickListener)

        // Web Setting
        val webSettings = webview?.settings
        webSettings?.javaScriptEnabled = true // Java Script 사용 가능
        webSettings?.builtInZoomControls = true // 확대 축소 기능
        webSettings?.displayZoomControls = false // 돋보기 없애기

        webview?.webViewClient = object : WebViewClient() {
            override
            fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }
        }
        webview?.loadUrl("https://www.google.com")
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        if (webview!!.canGoBack()) {
            webview!!.goBack()
        } else {
            finish()
        }
    }

    private var onClickListener = View.OnClickListener { v ->
        when (v.id) {
            R.id.btn_page1 -> btnPage1Click()
            R.id.btn_page2 -> btnPage2Click()
            R.id.btn_page3 -> btnPage3Click()
        }
    }

    private fun btnPage1Click() {
        webview?.loadUrl("https://www.google.com")
    }

    private fun btnPage2Click() {
        webview?.loadUrl("https://m.naver.com")
    }

    private fun btnPage3Click() {
        webview?.loadUrl("https://www.cnn.com")
    }






} // ----